class regFields{
    async fields(){
        
    }
}